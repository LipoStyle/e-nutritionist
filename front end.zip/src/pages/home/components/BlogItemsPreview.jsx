import React, { useEffect, useState } from 'react';
import Slider from "react-slick";
import { Link } from 'react-router-dom';
import image from "../../../images/home-images/section-two/1.jpg"
import "./blogitempreview.css"

const API_BASE_URL = 'https://e-nutritionist-9bb9c8f7b2bc.herokuapp.com'; 
const API_Local_Host = "http://localhost:3000"


const BlogItemsPreview = () => {
  
  const [blogs, setBlogs] = useState([]);

  useEffect(() => {
    fetch(`${API_BASE_URL}/blogs`) 
      .then(response => response.json())
      .then(data => setBlogs(data));
  }, []);

  var settings = {
    dots: true,
    infinite: true,
    speed: 500,
    slidesToShow: 4,
    slidesToScroll: 1,
    initialSlide: 0,
    responsive: [
      {
        breakpoint: 1024,
        settings: {
          slidesToShow: 3,
          slidesToScroll: 1,
          infinite: true,
          dots: true
        }
      },
      {
        breakpoint: 768,
        settings: {
          slidesToShow: 2,
          slidesToScroll: 1,
          infinite: true,
          dots: true
        }
      },
      {
        breakpoint: 500,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1,
        }
      }
    ]
  };

  return (
    <div className='blog-items-preview'>
      <h2 className='title'>Delve into Our Latest Articles and Discover New Perspectives</h2>
      <Slider {...settings}>
        {blogs.map((blog, index) => (
          <div className='blog-items-container-outer' key={index}>
            <div className='blog-items-container-inner'>
              <img src={`${API_BASE_URL}/${blog.img_url}`} alt={`${blog.title}`} />
              <h2>{blog.title}</h2>
              <p>{blog.description}</p>
              <Link to="/blogs">Go To Blogs</Link>
            </div>
          </div>
        ))}
      </Slider>
    </div>
  );
};

export default BlogItemsPreview;
