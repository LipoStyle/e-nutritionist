import React, { useState } from 'react';
import './bmicalculator.css';

const BMICalculator = () => {
  const [weight, setWeight] = useState('');
  const [height, setHeight] = useState('');
  const [bmi, setBMI] = useState(null);
  const [message, setMessage] = useState('');

  const calculateBMI = (e) => {
    e.preventDefault();

    if (weight > 0 && height > 0) {
      const heightInMeters = height / 100;
      const bmiValue = (weight / (heightInMeters * heightInMeters)).toFixed(2);
      setBMI(bmiValue);

      if (bmiValue < 18.5) {
        setMessage('You are underweight.');
      } else if (bmiValue >= 18.5 && bmiValue < 24.9) {
        setMessage('You have a normal weight.');
      } else if (bmiValue >= 25 && bmiValue < 29.9) {
        setMessage('You are overweight.');
      } else {
        setMessage('You are obese.');
      }
    } else {
      setMessage('Please enter valid weight and height.');
    }
  };

  return (
    <div className="bmi-calculator">
      <h1>Calculate Your BMI</h1>
      <p>Find out your Body Mass Index and take the first step towards a healthier you!</p>
      <form onSubmit={calculateBMI}>
        <div className="input-group">
          <label htmlFor="weight">Weight (kg):</label>
          <input
            type="number"
            id="weight"
            value={weight}
            onChange={(e) => setWeight(e.target.value)}
            placeholder="Enter your weight"
          />
        </div>
        <div className="input-group">
          <label htmlFor="height">Height (cm):</label>
          <input
            type="number"
            id="height"
            value={height}
            onChange={(e) => setHeight(e.target.value)}
            placeholder="Enter your height"
          />
        </div>
        <button type="submit">Calculate BMI</button>
      </form>
      {bmi && (
        <div className="result">
          <h2>Your BMI: {bmi}</h2>
          <p>{message}</p>
        </div>
      )}
    </div>
  );
};

export default BMICalculator;
