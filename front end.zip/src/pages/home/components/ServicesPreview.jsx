import React, { useState, useEffect } from 'react';
import Slider from "react-slick";
import { Link } from 'react-router-dom';

import "./servicepreview.css"

const API_BASE_URL = 'https://e-nutritionist-9bb9c8f7b2bc.herokuapp.com'; 
const API_Local_Host = "http://localhost:3000"

const ServicesPreview = () => {
  const [services, setServices] = useState([]);

  useEffect(() => {
    fetch(`${API_BASE_URL}/services.json`)  // Adjust the URL as needed
      .then(response => response.json())
      .then(data => setServices(data));
  }, []);

  var settings = {
    dots: true,
    infinite: true,
    speed: 500,
    slidesToShow: 4,
    slidesToScroll: 1,
    initialSlide: 0,
    responsive: [
      {
        breakpoint: 1024,
        settings: {
          slidesToShow: 3,
          slidesToScroll: 1,
          infinite: true,
          dots: true
        }
      },
      {
        breakpoint: 600,
        settings: {
          slidesToShow: 2,
          slidesToScroll: 1,
          initialSlide: 2
        }
      },
      {
        breakpoint: 500,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1
        }
      }
    ]
  };

  return (
    <div className='service-preview'>
      <h2 className='title'>Explore Our Exceptional Services Designed Just for You</h2>
      <Slider {...settings}>
        {services.map((service, index) => (
          <div className='service-container-outer' key={index}>
            <div className='service-container-inner'>
              <h2>{service.title}</h2>
              <p>{service.description}</p>
              <Link to="/services">Go To Service</Link>
            </div>
          </div>
        ))}
      </Slider>
    </div>
  );
};

export default ServicesPreview;
