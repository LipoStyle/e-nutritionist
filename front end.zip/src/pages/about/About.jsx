import "./about.css";
import PointComponent from "./PointComponent";
import { pointContent } from "./pointContent";
import { useState, useEffect } from "react";

const About = ({ localHost, heroku }) => {
  const [activePoint, setActivePoint] = useState(null);
  const [imageUrl, setImageUrl] = useState('');
  const [error, setError] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchImage = async () => {
      try {
        // Determine the base URL based on environment
        const baseUrl = process.env.NODE_ENV === 'development' ? localHost : heroku;
        const imageUrl = `${baseUrl}/public/images/aboutImage/image-of-me.jpg`;
        const response = await fetch(imageUrl);
        if (!response.ok) {
          throw new Error('Network response was not ok');
        }
        const url = URL.createObjectURL(await response.blob());
        setImageUrl(url);
        setLoading(false);
      } catch (error) {
        console.error('There has been a problem with your fetch operation:', error);
        setError(true);
        setLoading(false);
      }
    };

    fetchImage();
  }, [localHost, heroku]);

  const handlePointClick = (index) => {
    setActivePoint(index === activePoint ? null : index);
  };

  return (
    <div className="grid-container-about">
      <h1 className="name-of-doctor">
        Thymios Arvanitis <b className="proficient">Nutritionist</b>
      </h1>
      <h2 className="tag-quote">
        I'm Thymios Arvanitis, and I’m here to guide you on a journey to better
        health, whether it's through personalized nutrition, sports performance,
        or transformative lifestyle changes.
      </h2>
      {loading ? (
        <p>Loading image...</p>
      ) : error ? (
        <p>Error loading image</p>
      ) : (
        <img src={imageUrl} alt="my face" className="image-of-me" />
      )}

      {pointContent.map((information) => (
        <PointComponent
          key={information.id}
          title={information.title}
          description={information.description}
          active={activePoint === information.id}
          handlePoint={() => handlePointClick(information.id)}
        />
      ))}
    </div>
  );
};

export default About;
