import React from "react";
import Buttons from "../Buttons";
import ProgressBar from "../ProgressBar";
import { answerContent } from "./answerContent";
import "./screenfour.css"

const ScreenFour = ({ screen, nmscreen, formData, handleInputChange }) => {
  const handleDivClick = (id, name) => {
    const updatedAllergies = formData.allergies.includes(name)
      ? formData.allergies.filter((item) => item !== name)
      : [...formData.allergies, name];
    handleInputChange("allergies", updatedAllergies);
  };

  const progressPercentage = (nmscreen / 7) * 100; // Adjust based on your total screens

  return (
    <div id="screen4" className="screen4">
      <h1 className="title">Do you have any of the following allergies or intolerances?</h1>
      <div className="answer-container">
        <h4
          className={formData.allergies.includes("No, I don't have allergies issues") ? "answer-card active" : "answer-card"}
          onClick={() => handleDivClick(8, "No, I don't have allergies issues")}
        >
          No, I don't have allergies issues
        </h4>
        {answerContent.map((answer) => (
          <div
            key={answer.id}
            className={formData.allergies.includes(answer.name) ? "answer-card active" : "answer-card"}
            onClick={() => handleDivClick(answer.id, answer.name)}
          >
            <h4>{answer.name}</h4>
            <p>{answer.description}</p>
          </div>
        ))}
        <div
          className={formData.allergies.includes("I experience other chronic conditions not listed here.") ? "answer-card active" : "answer-card"}
          onClick={() => handleDivClick(9, "I experience other chronic conditions not listed here.")}
        >
          <h4>I experience other chronic conditions not listed here.</h4>
          <textarea
            name="#"
            id="other-answer"
            placeholder="Please specify if comfortable"
            value={formData.otherAllergies}
            onChange={(e) => handleInputChange("otherAllergies", e.target.value)}
          ></textarea>
        </div>
      </div>
      <Buttons changeScreen={screen} back={"screen3"} next={"screen5"} nb={3} nn={5} />
    </div>
  );
};

export default ScreenFour;
