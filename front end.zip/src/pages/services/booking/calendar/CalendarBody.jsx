import React from 'react';

const CalendarBody = ({ currentDate, handleSelectedDay}) => {
  // Helper function to reset time to midnight
  const resetTime = (date) => {
    return new Date(date.getFullYear(), date.getMonth(), date.getDate());
  };

  // Get the first day of the month
  const firstDayOfMonth = resetTime(new Date(currentDate.getFullYear(), currentDate.getMonth(), 1));
  // Get the last day of the month
  const lastDayOfMonth = resetTime(new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 0));
  // Get today's date reset to midnight
  const today = resetTime(new Date());

  // Function to check if a date is in the past, today, or in the future
  const getClassForDay = (date) => {
    const day = resetTime(date);
    if (day < today) {
      return 'past-day';
    } else if (day.getTime() === today.getTime()) {
      return 'current-day';
    } else {
      return 'future-day';
    }
  };

  // Array to store the days of the month
  const daysOfMonth = [];


  // Function to get a short version of the date
  const getShortDate = (date) => {
    return new Intl.DateTimeFormat('en-US', {year: 'numeric', month: 'short', day: 'numeric' }).format(date);
  };

  // Loop through each day of the month
  for (let i = 1; i <= lastDayOfMonth.getDate(); i++) {
    const day = new Date(firstDayOfMonth.getFullYear(), firstDayOfMonth.getMonth(), i);
    const dayClass = getClassForDay(day);
    const shortDate = getShortDate(day);
    daysOfMonth.push(
      <div key={i} className={`day ${dayClass}`} onClick={() =>handleSelectedDay(shortDate)} >
        {i}
      </div>
    );
  }

  return <div className="calendar-body">{daysOfMonth}</div>;
};

export default CalendarBody;
