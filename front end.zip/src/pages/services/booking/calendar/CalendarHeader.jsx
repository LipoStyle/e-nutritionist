import React from 'react';

const CalendarHeader = ({ currentDate, onPrevMonth, onNextMonth }) => {
  // Function to handle clicking on previous month button
  const handlePrevMonthClick = () => {
    if (onPrevMonth) {
      onPrevMonth();
    }
  };

  // Function to handle clicking on next month button
  const handleNextMonthClick = () => {
    if (onNextMonth) {
      onNextMonth();
    }
  };

  return (
    <div className="calendar-header">
      <div className='month-navigation' onClick={handlePrevMonthClick}>&#60;</div>
      <div className='month-name'>{currentDate.toLocaleString('default', { month: 'long' })}</div>
      <div className='month-navigation' onClick={handleNextMonthClick}>&#62;</div>
    </div>
  );
};

export default CalendarHeader;
