import React, { useState } from 'react';

const TimePicker = ({ onTimeSelect }) => {
  const [selectedTime, setSelectedTime] = useState('');

  const handleTimeChange = (event) => {
    const time = event.target.value;
    setSelectedTime(time);
    if (onTimeSelect) {
      onTimeSelect(time);
    }
  };

  return (
    <div className="time-picker">
      <label htmlFor="time">Select Time:</label>
      <input
        type="time"
        id="time"
        value={selectedTime}
        onChange={handleTimeChange}
      />
    </div>
  );
};

export default TimePicker;
