import "./scheduleOfMeeting.css"
import TimePicker from './TimePicker';

const ScheduleOfMeeting = ({handleTimeSelect}) => {

  return (
    <div className="schedule-of-meeting">
      <h1 className="title-of-schedule-meeting">Please select a convenient time slot from the options below:</h1>
      <TimePicker onTimeSelect={handleTimeSelect} />
    </div>
  );
};

export default ScheduleOfMeeting;