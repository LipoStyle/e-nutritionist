import { useState } from "react";

const API_local_host = 'http://localhost:3000/'; 
const API_BASE_URL = 'https://e-nutritionist-b1d035f17120.herokuapp.com/'; 



const Payment = ({ priceOfProgram, selectedTime, selectedDay, typeOfConsultation }) => {
  const [userMessage, setUserMessage] = useState("");

  const handleUserMessageChange = (e) => setUserMessage(e.target.value);

  const handleSubmit = async () => {
    const bookingDetails = {
      date: selectedDay,
      time: selectedTime,
      type_of_consultation: typeOfConsultation,
      price_of_consultation: priceOfProgram,
      user_message: userMessage
    };

    try {
      const response = await fetch(`${API_BASE_URL}/bookings`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ booking: bookingDetails }),
      });

      if (!response.ok) {
        throw new Error('Network response was not ok');
      }

      const data = await response.json();
      console.log('Success:', data);
    } catch (error) {
      console.error('Error:', error);
    }
  };

  return (
    <div className="payment">
      <h3>Complete your booking</h3>
      <div>
        <label>
          Your Message:
          <textarea value={userMessage} onChange={handleUserMessageChange} />
        </label>
      </div>
      <button onClick={handleSubmit}>Submit Booking</button>
    </div>
  );
};

export default Payment;
