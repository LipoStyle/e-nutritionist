import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { sanitizeHtml } from '../../components/usefullfunctions/sanitizeHtml';
import "./singleblogstyle.css";

const API_BASE_URL = 'https://e-nutritionist-9bb9c8f7b2bc.herokuapp.com'; 
const API_Local_Host = "http://localhost:3000"


const BlogDetail = () => {
  const { slug } = useParams();
  const [blog, setBlog] = useState(null);
  const [error, setError] = useState(null);

  const API_URL = API_BASE_URL; // Update this conditionally based on the environment


  useEffect(() => {
    if (slug) {
      fetch(`${API_URL}/blogs/${slug}`)
        .then(response => {
          if (!response.ok) {
            throw new Error('Network response was not ok');
          }
          return response.json();
        })
        .then(data => setBlog(data))
        .catch(error => setError(error));
    }
  }, [slug]);

  if (error) {
    return <div>Error: {error.message}</div>;
  }

  if (!blog) {
    return <div>Loading...</div>;
  }

  return (
    <div className='blog-detail-background'>
      <div className="blog-detail" dangerouslySetInnerHTML={{ __html: sanitizeHtml(blog.content) }} />
    </div>
  );
};

export default BlogDetail;
