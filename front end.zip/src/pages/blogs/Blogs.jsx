import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import "./blog.css";
import backgroundImage from "../../images/blogimages/blogBackground.jpg";

const API_BASE_URL = 'https://e-nutritionist-9bb9c8f7b2bc.herokuapp.com'; 
const API_Local_Host = "http://localhost:3000"


const Blogs = () => {
  const [blogs, setBlogs] = useState([]);

  const API_URL = API_BASE_URL; // Update this conditionally based on the environment


  useEffect(() => {
    fetch(`${API_URL}/blogs`) 
      .then(response => response.json())
      .then(data => setBlogs(data));
  }, []);

  return (
    <div className='blogs'>
      <h1 className='title'>Blogs</h1>
      <ul className='blog-container'>
        {blogs.map(blog => (
          <li key={blog.id} className='blog'>
            <img src={`${API_URL}/${blog.img_url}`} alt="test" className='blog-image'/>
            <h2 className='blog-title'>{blog.title}</h2>
            <p className='blog-description'>{blog.description}</p>
            <Link to={`/blogs/${blog.slug}`} className='blog-a'>Read More</Link>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default Blogs;
